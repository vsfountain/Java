package com.hw1.q15;

public interface MathInterface {
	
	//int operate(int x, int y);
	
	int multiply(int x, int y);
	
	int divide(int x, int y);
	
	int add(int x, int y);
	
	int subtract(int x, int y);
	
	

}
