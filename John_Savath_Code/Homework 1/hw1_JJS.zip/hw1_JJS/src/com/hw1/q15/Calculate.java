package com.hw1.q15;

public class Calculate implements MathInterface {

	@Override
	public int multiply(int x, int y) {
		// TODO Auto-generated method stub
		return x * y;
	}

	@Override
	public int divide(int x, int y) {
		// TODO Auto-generated method stub
		return x/y;
	}

	@Override
	public int add(int x, int y) {
		// TODO Auto-generated method stub
		return x + y;
	}

	@Override
	public int subtract(int x, int y) {
		// TODO Auto-generated method stub
		return x -y;
	}

	

	
}
