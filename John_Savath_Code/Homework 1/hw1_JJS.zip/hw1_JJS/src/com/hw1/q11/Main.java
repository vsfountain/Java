/**
 * 
 */
package com.hw1.q11;

/**
 * @author JohnJosephSavath
 *
 *Q11. Write a program that would access two float-variables 
 *from a class that exists in another package. 
 *Note, you will need to create two packages to demonstrate the solution.
 *
 */
import com.hw1.q11.p2.*;;
public class Main {

	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Float2 a = new Float2();
		a.print();
	}

}
