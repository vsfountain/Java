package com.hw1.q11.p1;

public class Float1 {
	public float a1 = 10f;//use public to make class visible to other package
	
	
}
