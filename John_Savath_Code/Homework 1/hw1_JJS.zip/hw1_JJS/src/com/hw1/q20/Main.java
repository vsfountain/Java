/**
 * 
 */
package com.hw1.q20;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Iterator;
import java.util.List;

/**
 * @author JohnJosephSavath
 *
 *	Q20. Create a notepad file called Data.txt and enter the following: 
	Mickey:Mouse:35:Arizona
	Hulk:Hogan:50:Virginia
	Roger:Rabbit:22:California
	Wonder:Woman:18:Montana

	Write a program that would read from the file and print it out to the 
	screen in the following format:
	
	Name: Mickey Mouse
	Age: 35 years
	State: Arizona State
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		


	}
}
