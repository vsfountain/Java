package com.hw1.q_5;

//Q5. Write a substring method that accepts a string str and an integer idx 
//and returns the substring contained between 0 and idx-1 inclusive.  
//Do NOT use any of the existing substring methods in the String, 
//StringBuilder, or StringBuffer APIs.

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
