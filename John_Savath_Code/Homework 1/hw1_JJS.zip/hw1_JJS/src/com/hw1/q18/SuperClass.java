package com.hw1.q18;

public abstract class SuperClass {
	
	public abstract boolean checkCaseOfStringUp(String mySt);
	
	public abstract String cvtCase(String input);
	
	public abstract Integer cvtStToint(String num);

}
