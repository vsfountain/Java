/**
 * 
 */
package com.hw1.q10;

/**
 * @author JohnJosephSavath
 * 
 * 
 * Q10. Find the minimum of two numbers using ternary operators.
 * 
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 10;
		int y = 5;
		int min,result;
		min = x<y ? x:y;
		System.out.println("The min is: "+min);
	}

}
