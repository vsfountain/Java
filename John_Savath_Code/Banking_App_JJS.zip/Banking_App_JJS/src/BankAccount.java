import java.io.Serializable;
import java.util.Scanner;

public class BankAccount implements Serializable {
    int balance;
    int previousTransaction;
    String customerName;
    String customerId;
    
    //Creates string value for customer name
    BankAccount(String cname, String cid){
        customerName = cname;
        customerId = cid;
    }
    
    //method to run deposit transactions
    void deposit(int amount){//method to deposit money
        if(amount != 0){
            balance = balance + amount;//adds value to balance
            previousTransaction = amount;//keeping track of amount deposited

        }
    }
    
    //method to run withdraw transaction
    void withdraw(int amount){//method to withdraw money
        if(amount !=0){
            balance = balance - amount;//subtract value to balance
            previousTransaction = -amount;//keeping track of amount withdrew
        }
    }
    
    //method to run a display of previous transaction
    void getPreviousTransation(){//printing transaction history
        if(previousTransaction > 0){
            System.out.println("Deposited: " + previousTransaction);
        }else if(previousTransaction < 0){
            System.out.println("Withdrawn: " + Math.abs(previousTransaction));
        }else{
            System.out.println("No transaction occured");
        }
    }
    
    //method to open user menu and prompt for a selection of actions
    void showMenu(){
        char option ='\0';
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome " + customerName);
        System.out.println("Your ID is " + customerId);
        System.out.println("\n");
        System.out.println("A. Check Balance");
        System.out.println("B. Deposit");
        System.out.println("C. Withdraw");
        System.out.println("D. Previous transaction");
        System.out.println("E. Exit");

        do{
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("Enter an option");
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
            option = scanner.next().charAt(0);
            System.out.println("\n");
            switch(option){

                case'A':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Balance = "+balance);
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("\n");
                    break;
                case'B':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Enter amount to depost: ");
                    System.out.println("+++++++++++++++++++++++++++++++");
                    int amount = scanner.nextInt();
                    deposit(amount);
                    System.out.println("\n");
                    break;
                case'C':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Enter amount to withdraw: ");
                    System.out.println("+++++++++++++++++++++++++++++++");
                    int amount2 = scanner.nextInt();
                    withdraw(amount2);
                    System.out.println("\n");
                    break;
                case'D':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Previous Transaction: ");
                    getPreviousTransation();
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("\n");
                    break;
                case 'E':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    break;
                default:
                    System.out.println("Invalid option! Please try again");
                    break;
            }
        } while(option != 'E'); {
            System.out.println("Returning to main menu.");
            System.out.println("+++++++++++++++++++++++++++++++");
        }
    }
    
    //admin menu options
    void adminMenu(){
    	char option ='\0';
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome " + customerName);
        System.out.println("Your ID is " + customerId);
        System.out.println("\n");
        System.out.println("A. Check Balance");
        System.out.println("B. Deposit");
        System.out.println("C. Withdraw");
        System.out.println("D. Previous transaction");
        System.out.println("E. Exit");

        do{
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("Enter an option");
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
            option = scanner.next().charAt(0);
            System.out.println("\n");
            switch(option){

                case'A':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Balance = "+balance);
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("\n");
                    break;
                case'B':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Enter amount to depost: ");
                    System.out.println("+++++++++++++++++++++++++++++++");
                    int amount = scanner.nextInt();
                    deposit(amount);
                    System.out.println("\n");
                    break;
                case'C':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Enter amount to withdraw: ");
                    System.out.println("+++++++++++++++++++++++++++++++");
                    int amount2 = scanner.nextInt();
                    withdraw(amount2);
                    System.out.println("\n");
                    break;
                case'D':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Previous Transaction: ");
                    getPreviousTransation();
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("\n");
                    break;
                case 'E':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    break;
                default:
                    System.out.println("Invalid option! Please try again");
                    break;
            }
        } while(option != 'E'); {
            System.out.println("Returning to main menu.");
            System.out.println("+++++++++++++++++++++++++++++++");
        }
    }
    
    //employee menu
    void employeeMenu() {
    	char option ='\0';
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome " + customerName);
        System.out.println("Your ID is " + customerId);
        System.out.println("\n");
        System.out.println("A. Check Balance");
        System.out.println("B. Deposit");
        System.out.println("C. Withdraw");
        System.out.println("D. Previous transaction");
        System.out.println("E. Exit");

        do{
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("Enter an option");
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++");
            option = scanner.next().charAt(0);
            System.out.println("\n");
            switch(option){

                case'A':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Balance = "+balance);
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("\n");
                    break;
                case'B':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Enter amount to depost: ");
                    System.out.println("+++++++++++++++++++++++++++++++");
                    int amount = scanner.nextInt();
                    deposit(amount);
                    System.out.println("\n");
                    break;
                case'C':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Enter amount to withdraw: ");
                    System.out.println("+++++++++++++++++++++++++++++++");
                    int amount2 = scanner.nextInt();
                    withdraw(amount2);
                    System.out.println("\n");
                    break;
                case'D':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("Previous Transaction: ");
                    getPreviousTransation();
                    System.out.println("+++++++++++++++++++++++++++++++");
                    System.out.println("\n");
                    break;
                case 'E':
                    System.out.println("+++++++++++++++++++++++++++++++");
                    break;
                default:
                    System.out.println("Invalid option! Please try again");
                    break;
            }
        } while(option != 'E'); {
            System.out.println("Returning to main menu.");
            System.out.println("+++++++++++++++++++++++++++++++");
        }
    }
}
