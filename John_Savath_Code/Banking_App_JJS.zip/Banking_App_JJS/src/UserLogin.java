
import java.io.Serializable;
import java.util.Scanner;

public class UserLogin extends Customer implements Serializable {

    public UserLogin(String name, String username, String password, String email, String accountType) {
		super(name, username, password, email, accountType);
		// TODO Auto-generated constructor stub
	}
	String name, user, pass, email, acctType;
	public void login(){
        Scanner input = new Scanner(System.in);

        

        //Prompts user to enter username and password
        System.out.println("Enter your username: ");
        user = input.nextLine();

        System.out.println("Enter your password: ");
        pass = input.nextLine();
        
        //Create object of customer to reference the value of username and password
        Customer a = new Customer(name, user, pass, email, acctType);
        
        //checks to see if username and password is valid
        if(user.equals(a.username) && (pass.equals(a.password))) {
            System.out.println("User is authenticated");
            /*
            * To begin using bank transactions here
            * */
            BankAccount obj1 = new BankAccount(user, "001");
            obj1.showMenu();


        //login info for bank admin only    
        }else if (user.equals("admin") && (pass.equals("pass"))) {
        	BankAccount obj2 = new BankAccount(user, "admin001");
        	obj2.adminMenu();
        
        //login info for employee only	
        }else if (user.equals("employee") && (pass.equals("pass"))) {
        	BankAccount obj3 = new BankAccount(user, "employee001");
        	obj3.employeeMenu();
        }
        //other inputs will prompt an "invalid login" message
        else{
            System.out.println("Invalid Login!");
        }
    }
}
