import java.io.BufferedReader;
import java.util.Scanner;

public class Main {
    public static void main (String[] args){

        String input;
        Scanner scanner = new Scanner(System.in);
        do{
            System.out.println("Do you have an account?" +
                    "\n To register for an account type: register." +
                    "\n To log into your account type: login" +
                    "\n To exit type: exit");
            input = scanner.nextLine();
            //if user types login, they will be prompted to login
            if (input.equals("login")){
                UserLogin userlg = new UserLogin(input, input, input, input, input);//Create object for user login
                userlg.login();//Run login method
              //if user types register, they will be prompted to apply  
            } else if(input.equals("register")){
            	Registration reg = new Registration();
            	reg.registration();
            	System.out.println("Please wait for approval!");
            	
             //if user enters exit, then they will exit the program	
            }else if(input.equals("exit")){
            	System.out.println("Thank you for using our services!");
                break;
             //other entries will prompt an "invalid input" message   
            }else{
                System.out.println("invalid input, please try again");
            }

        }while(true);
        //After user types exit, the loop ends and system will exit
        System.exit(0);//Exit/terminate program

    }
}
