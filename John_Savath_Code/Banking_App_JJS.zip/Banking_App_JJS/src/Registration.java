import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;


public class Registration implements Serializable {


	//method to start user registration
    public void registration(){
    	
        Scanner input = new Scanner(System.in);
        String filename = "./Customer.txt";
		
        Scanner s = new Scanner(System.in);
        
        
        System.out.println("Enter your email: ");
		String email = s.nextLine();
		System.out.println("Create your username: ");
		String username = s.nextLine();
		System.out.println("Create your password: ");
		String password = s.nextLine();
		System.out.println("Which account would you like to open? Checking or savings? ");
		String accountType = s.nextLine();
		System.out.println("Enter your Name: ");
		String name = s.nextLine();
		
		Customer c = new Customer(name, username, password, email, accountType);
		
		
		
		
		//saving user inputs to file and reading back the input
		writeObject(filename, c);
		readObject(filename);
		
	}
    
    //method to read from file
	static void readObject(String filename) {
		try(ObjectInputStream ois = new ObjectInputStream(
				new FileInputStream(filename)))
		{
			Object obj = ois.readObject();//de-serialization
			System.out.println(obj);
			
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	//method to write user input to file
	static void writeObject(String filename, Object obj) {
		try(ObjectOutputStream oos =new ObjectOutputStream(
				new FileOutputStream(filename)))
		{
			oos.writeObject(obj); //serialization
			
		}catch(IOException e) {
			e.printStackTrace();
		}


    }

}
