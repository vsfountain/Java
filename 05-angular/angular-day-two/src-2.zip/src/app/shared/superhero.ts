export interface ISuperhero {
    name: string;
    ability: string;
    organization: string;
    image: string;
}
